<template>
    <div>
        <header>
            Myweb.com
        </header>
    </div>
</template>


<script>
</script>

<style scoped>
  header {
    background: #2196F3;
    border-bottom: 4px solid #607D8B;
    box-sizing: border-box;
    padding: 30px;
    color: #ffffff;
    font-size: 30px;
  }
</style>
