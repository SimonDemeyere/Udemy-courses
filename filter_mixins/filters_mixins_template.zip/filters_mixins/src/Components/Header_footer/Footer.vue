<template>
    <div>
        <footer>
            Footer
        </footer>
    </div>
</template>

<script>
    
</script>

<style>
    footer {
        background: #607D8B;
        padding: 20px;
        color: #fff;
    }
</style>
